(function($){
	$(window).load(function(){
 
		$(".table-body-window_moves").mCustomScrollbar({
			theme:"dark-3"
		});

		$(".chats-window-one").mCustomScrollbar({
			theme:"dark-3"
		});

		$('.exchange-filed-window-f').mCustomScrollbar({
			theme:"dark-3"
		});
 
	});
})(jQuery);